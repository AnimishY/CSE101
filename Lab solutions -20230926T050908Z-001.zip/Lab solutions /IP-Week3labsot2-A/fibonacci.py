# function generates and returns list of first n fibonacci numbers
def generate_fibonacci(n):
    fibonacci_sequence = [0, 1]  # Initialize the first two numbers in the Fibonacci sequence

    # Generate the Fibonacci sequence up to the Nth number
    while len(fibonacci_sequence) < n:
        next_number = fibonacci_sequence[-1] + fibonacci_sequence[-2]  #add the last two elements of the list
        fibonacci_sequence.append(next_number)                         #append newly generated number to list

    return fibonacci_sequence

# Input N
n = int(input())

# call function to generate n fibonacci numbers
lst = generate_fibonacci(n)

# print list content
for i in lst:
    print(i,end=" ")
