n=int(input())
spaces=0
if n%2!=0:
    while n>0:
        print(spaces*(" "),end="")
        print((n)*"* ",end="")
        print(" ",end="")
        n-=2
        spaces += 2
        print()
else:
    print(-1)