# Initialize the first two Fibonacci numbers
fibonacci = [1, 1]

# Compute and store Fibonacci numbers up to the desired value
def fib(n):
    for i in range(2, 6):
        next_fib = fibonacci[-1] + fibonacci[-2]
        fibonacci.append(next_fib)
    if n <=5:
        return fibonacci[n]
    else:
        return -1

n = int(input().strip())
# Print the nth Fibonacci number
print(fib(n))
