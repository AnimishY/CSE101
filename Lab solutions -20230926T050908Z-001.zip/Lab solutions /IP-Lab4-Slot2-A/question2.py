def sqrt(x):

    left, right = 0, x
    while right - left > 1e-10:
        mid = (left + right) / 2
        mid_squared = mid * mid

        if mid_squared < x:
            left = mid
        else:
            right = mid

    return (left + right) / 2


def checkPrime(x):
    if x <= 1:
        return False
    if x <= 3:
        return True
    if x % 2 == 0 or x % 3 == 0:
        return False
    i = 5
    while i * i <= x:
        if x % i == 0 or x % (i + 2) == 0:
            return False
        i += 6
    return True

def factor(n):
    for i in range(2, int(sqrt(n))):
        if(checkPrime(i) and n%i==0):
            print(i)
            print(n//i)

n =int(input())
factor(n)
