def printPattern(n1, n2):
    i=n1;
    while i>=-n1:
        cnt=i
        if i<0:
            cnt=-i
        print("%"*cnt, end='')
        print('$'*(2*(n1-cnt)+1), end='')
        print('%'*cnt)
        i-=1

n1=int(input())
n2=int(input())
printPattern(n1, n2)