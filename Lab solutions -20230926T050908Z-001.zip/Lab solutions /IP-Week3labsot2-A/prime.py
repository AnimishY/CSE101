#function that check & returns True if n is prime and False otherwise
def isPrime(n):
    #check for all 1<i<n
    for i in range(2,n):
        #if i divides n, then n is not prime
        if n%i==0:
            return False
    # if no i divides n then n is prime
    return True

#take n as input
n = int(input())

print("Prime" if isPrime(n) else "No")