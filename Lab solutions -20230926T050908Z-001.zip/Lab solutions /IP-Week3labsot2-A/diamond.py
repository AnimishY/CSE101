n = int(input())    #take n as input

# Print the top half of the pattern
for i in range(1, n + 1, 2):
    # Print leading spaces
    print(" " * (n - i), end="")
    # Print asterisks
    print("* " * i)

# Print the bottom half of the pattern
for i in range(n - 2, 0, -2):
    # Print leading spaces
    print(" " * (n - i), end="")
    # Print asterisks
    print("* " * i)