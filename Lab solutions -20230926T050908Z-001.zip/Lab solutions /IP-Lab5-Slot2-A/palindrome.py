def is_palindrome(s):
    if s == '$' or s == '':
        return True

    # Check if the string contains any non-lowercase English letters
    if not s.islower():
        return False

    # Check for palindrome condition
    n = len(s)
    for i in range(n // 2):
        if s[i] != s[n - 1 - i]:
            return False
    return True


# Input
S = input().strip()

# Check if it's a palindrome and print the result
if is_palindrome(S):
    print("TRUE")
else:
    print("FALSE")
