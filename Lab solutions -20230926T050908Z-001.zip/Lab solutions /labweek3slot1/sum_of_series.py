n=int(input())
x=0
flag=False
for i in range(0,n):
    a=int(input())
    x=x+a
    if flag==False:
        if a%2!=0:
            if a%3!=0:
              flag=True
        else:
            pass
if flag==True:
    x=x+2
else:
    pass

print(x)